import DocumentUpload from "../components/DocumentUpload";

export default function Content(){
    return (
        <>
            <h1>Content</h1>
            <DocumentUpload />
        </>
    );
};
