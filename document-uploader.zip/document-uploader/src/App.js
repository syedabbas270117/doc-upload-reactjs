import './App.css';
import './tailwind.css'
import Layout from "./layouts/index";

function App() {
  return (
    <div className="App">
        <Layout />
    </div>
  );
}

export default App;
